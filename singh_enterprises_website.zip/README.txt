SINGH ENTERPRISES WEBSITE — QUICK START

Files:
- index.html: responsive one-page website.

PREVIEW:
Open index.html in a browser. Internet is required for the sample photos.

FREE PUBLISHING OPTION (GitHub Pages):
1. Create/sign in to a GitHub account at https://github.com/
2. Create a new public repository named singh-enterprises-website.
3. Upload index.html to the repository root.
4. Open repository Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. GitHub will provide a free website address. Publishing can take a few minutes.

CUSTOM DOMAIN:
A domain such as singhenterprises.in usually costs extra and availability must be checked with a registrar. After purchase, configure it in GitHub Pages settings and follow the DNS records shown by GitHub. Domain registration and renewals are not free.

BEFORE GOING LIVE:
- Confirm you have permission to use all phone numbers shown.
- Replace sample stock photos with your real project photos.
- Verify that “Pan India” reflects your actual service capacity; travel, labour and material logistics may vary by location.
- Add GST/business details only if applicable and verified.
- Test all phone and WhatsApp links on a mobile phone.
- This is a static website. The enquiry form opens WhatsApp; it does not store submissions on a server.
